const SETTINGS_LOCALE = {
 'English': ['Get your key at ', 'Connected', 'Connection failed', 'Check the API endpoint, key, model and network.'],
 'Chinese (Simplified)': ['获取密钥：', '连接成功', '连接失败', '请检查 API 地址、密钥、模型和网络。'],
 'Japanese': ['API キーを取得：', '接続成功', '接続失敗', 'API アドレス、キー、モデル、ネットワークを確認してください。'],
 'Korean': ['API 키 발급: ', '연결 성공', '연결 실패', 'API 주소, 키, 모델 및 네트워크를 확인하세요.']
};
function settingsText(index) { return (SETTINGS_LOCALE[currentModelLanguage] || SETTINGS_LOCALE.English)[index]; }
/* ============================================================
   Context Explain — popup.js
   ============================================================ */

let currentModelLanguage = 'English';
const MODEL_COPY = {
 'English': ['Fetch models','Loading…','Enter API endpoint and key first.','Models loaded. Select or type a model.','Failed to fetch models. You can enter a model manually.','Use custom model: ','e.g. '],
 'Chinese (Simplified)': ['获取模型列表','正在获取…','请先填写 API 地址和密钥。','模型已获取，可搜索选择或自行输入。','获取失败，可手动输入模型名称。','使用自定义模型：','例如：'],
 'Japanese': ['モデルを取得','取得中…','API エンドポイントとキーを入力してください。','モデルを検索・選択するか、直接入力できます。','取得できません。モデル名を直接入力できます。','カスタムモデルを使用：','例：'],
 'Korean': ['모델 목록 가져오기','가져오는 중…','API 주소와 키를 입력하세요.','모델을 검색하거나 직접 입력하세요.','가져오지 못했습니다. 모델 이름을 직접 입력할 수 있습니다.','사용자 지정 모델: ','예: ']
};
function modelCopy() { return MODEL_COPY[currentModelLanguage] || MODEL_COPY.English; }
function refreshModelLanguage() {
 const t = modelCopy();
 for(const id of ['text-models-result','vision-models-result']) {const el=document.getElementById(id);if(el?.dataset.state==='success')el.textContent=t[3];}
 const hint=document.getElementById('keyHint'); const selected=document.getElementById('provider'); if(hint && selected) hint.textContent=settingsText(0)+(PROVIDER_DEFAULTS[selected.value]?.keyHint || '');
 for (const prefix of ['text','vision']) { const b=document.getElementById('fetch-'+prefix+'-models'); if(b) b.textContent=t[0]; }
 const input=document.getElementById('apiModel'); const provider=document.getElementById('provider');
 if(input && provider) input.placeholder=t[6]+(PROVIDER_DEFAULTS[provider.value]?.placeholder || 'model-name');
 const vision=document.getElementById('vision-model'); if(vision) vision.placeholder=t[6]+'gpt-4o / gemini-pro-vision';
}
const UI_STRINGS = {
  'English': {
    tabSettings: 'Settings', tabHistory: 'History',
    sectionAI: 'AI Settings', tabText: 'Text API', tabVision: 'Vision API',
    labelProvider: 'Provider', labelApiKey: 'API Key', labelModel: 'Model',
    labelBaseUrl: 'Base URL', labelEndpoint: 'API Endpoint',
    labelEnableVision: 'Enable Image Analysis',
    hintVision: 'Enables right-click image explain/ask. Requires a vision-capable model.',
    labelUseTextConfig: 'Use Text API configuration',
    hintUseTextConfig: 'Copies Text API endpoint and key. Model must still be set manually.',
    sectionBehavior: 'Behavior',
    labelResponseLang: 'Response Language', labelTheme: 'Theme',
    labelTranslateLang: 'Translation Target Language',
    btnSave: 'Save Settings', msgSaved: 'Settings saved!',
    tabHistorySearch: 'Search history…',
    btnExport: 'Export ZIP', btnClear: 'Clear',
    optLangAuto: 'Auto-detect (match selected text)',
    themeSystem: 'Follow System', themeLight: 'Light', themeDark: 'Dark',
    testConnectionTitle: 'Test connection',
  },
  'Chinese (Simplified)': {
    tabSettings: '设置', tabHistory: '历史',
    sectionAI: 'AI 设置', tabText: '文本 API', tabVision: '视觉 API',
    labelProvider: '服务商', labelApiKey: 'API 密钥', labelModel: '模型',
    labelBaseUrl: '基础 URL', labelEndpoint: 'API 端点',
    labelEnableVision: '启用图片分析',
    hintVision: '启用右键图片解释/提问功能，需要支持视觉的模型。',
    labelUseTextConfig: '使用文本 API 配置',
    hintUseTextConfig: '复制文本 API 的端点和密钥，模型仍需手动填写。',
    sectionBehavior: '行为设置',
    labelResponseLang: '回复语言', labelTheme: '主题',
    labelTranslateLang: '翻译目标语言',
    btnSave: '保存设置', msgSaved: '设置已保存！',
    tabHistorySearch: '搜索历史…',
    btnExport: '导出 ZIP', btnClear: '清除',
    optLangAuto: '自动检测（匹配所选文本）',
    themeSystem: '跟随系统', themeLight: '浅色', themeDark: '深色',
    testConnectionTitle: '测试连接',
  },
  'Japanese': {
    tabSettings: '設定', tabHistory: '履歴',
    sectionAI: 'AI 設定', tabText: 'テキスト API', tabVision: 'ビジョン API',
    labelProvider: 'プロバイダー', labelApiKey: 'API キー', labelModel: 'モデル',
    labelBaseUrl: 'ベース URL', labelEndpoint: 'API エンドポイント',
    labelEnableVision: '画像解析を有効にする',
    hintVision: '右クリックで画像の説明/質問が可能になります。ビジョン対応モデルが必要です。',
    labelUseTextConfig: 'テキスト API 設定を使用',
    hintUseTextConfig: 'テキスト API のエンドポイントとキーをコピーします。モデルは手動で設定してください。',
    sectionBehavior: '動作設定',
    labelResponseLang: '回答言語', labelTheme: 'テーマ',
    labelTranslateLang: '翻訳先言語',
    btnSave: '設定を保存', msgSaved: '設定が保存されました！',
    tabHistorySearch: '履歴を検索…',
    btnExport: 'ZIP エクスポート', btnClear: 'クリア',
    optLangAuto: '自動検出（選択テキストに合わせる）',
    themeSystem: 'システムに従う', themeLight: 'ライト', themeDark: 'ダーク',
    testConnectionTitle: '接続テスト',
  },
  'Korean': {
    tabSettings: '설정', tabHistory: '기록',
    sectionAI: 'AI 설정', tabText: '텍스트 API', tabVision: '비전 API',
    labelProvider: '공급자', labelApiKey: 'API 키', labelModel: '모델',
    labelBaseUrl: '기본 URL', labelEndpoint: 'API 엔드포인트',
    labelEnableVision: '이미지 분석 활성화',
    hintVision: '우클릭 이미지 설명/질문 기능을 활성화합니다. 비전 지원 모델이 필요합니다.',
    labelUseTextConfig: '텍스트 API 설정 사용',
    hintUseTextConfig: '텍스트 API의 엔드포인트와 키를 복사합니다. 모델은 직접 설정해야 합니다.',
    sectionBehavior: '동작 설정',
    labelResponseLang: '응답 언어', labelTheme: '테마',
    labelTranslateLang: '번역 대상 언어',
    btnSave: '설정 저장', msgSaved: '설정이 저장되었습니다!',
    tabHistorySearch: '기록 검색…',
    btnExport: 'ZIP 내보내기', btnClear: '지우기',
    optLangAuto: '자동 감지 (선택한 텍스트에 맞춤)',
    themeSystem: '시스템 따르기', themeLight: '라이트', themeDark: '다크',
    testConnectionTitle: '연결 테스트',
  },
};

function applyUILanguage(lang) {
  currentModelLanguage = lang;
  const s = UI_STRINGS[lang] || UI_STRINGS['English'];
  refreshModelLanguage();
  renderPromptEditors();

  // Tab nav
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    if (btn.dataset.tab === 'settings') btn.textContent = s.tabSettings;
    if (btn.dataset.tab === 'history') btn.textContent = s.tabHistory;
  });

  // AI Settings section title
  const aiSectionTitle = document.querySelector('#page-settings .section-title');
  if (aiSectionTitle) aiSectionTitle.textContent = s.sectionAI;

  // AI sub-tabs
  document.querySelectorAll('.ai-tab-btn').forEach(btn => {
    if (btn.dataset.aiTab === 'text') btn.textContent = s.tabText;
    if (btn.dataset.aiTab === 'vision') btn.textContent = s.tabVision;
  });

  // Labels — use data attributes for targeting
  const setLabel = (forId, text) => {
    const el = document.querySelector(`label[for="${forId}"]`);
    if (el) el.textContent = text;
  };
  setLabel('provider', s.labelProvider);
  setLabel('apiKey', s.labelApiKey);
  setLabel('apiModel', s.labelModel);
  setLabel('apiBaseUrl', s.labelBaseUrl);
  setLabel('vision-endpoint', s.labelEndpoint);
  setLabel('vision-key', s.labelApiKey);
  setLabel('vision-model', s.labelModel);
  setLabel('responseLang', s.labelResponseLang);
  setLabel('theme-select', s.labelTheme);
  setLabel('translate-lang', s.labelTranslateLang);

  // Checkbox labels (span inside label)
  const visionEnabledSpan = document.querySelector('label.checkbox-label:has(#vision-enabled) span');
  if (visionEnabledSpan) visionEnabledSpan.textContent = s.labelEnableVision;
  const useTextSpan = document.querySelector('label.checkbox-label:has(#vision-use-text-config) span');
  if (useTextSpan) useTextSpan.textContent = s.labelUseTextConfig;

  // Hints
  const visionHint = document.querySelector('#vision-enabled')?.closest('.setting-group')?.querySelector('.hint');
  if (visionHint) visionHint.textContent = s.hintVision;
  const useTextHint = document.querySelector('#vision-use-text-config')?.closest('.setting-group')?.querySelector('.hint');
  if (useTextHint) useTextHint.textContent = s.hintUseTextConfig;

  // Behavior section title (second .section-title)
  const sectionTitles = document.querySelectorAll('.section-title');
  if (sectionTitles[1]) sectionTitles[1].textContent = s.sectionBehavior;

  // Save button
  const saveBtn = document.querySelector('.btn-save');
  if (saveBtn) saveBtn.textContent = s.btnSave;

  // History search placeholder
  const histSearch = document.querySelector('#histSearch');
  if (histSearch) histSearch.placeholder = s.tabHistorySearch;

  // Export / Clear buttons
  const btnExport = document.querySelector('#btnExport');
  if (btnExport) btnExport.textContent = s.btnExport;
  const btnClear = document.querySelector('#btnClear');
  if (btnClear) btnClear.textContent = s.btnClear;

  // Test connection button tooltips
  document.querySelectorAll('.btn-model-check').forEach(btn => {
    btn.title = s.testConnectionTitle;
  });

  // Response Language select — "Auto-detect" option
  const autoOpt = document.querySelector('#responseLang option[value="auto"]');
  if (autoOpt) autoOpt.textContent = s.optLangAuto;

  // Theme select options
  const themeSelect = document.querySelector('#theme-select');
  if (themeSelect) {
    const opts = themeSelect.options;
    for (const opt of opts) {
      if (opt.value === 'system') opt.textContent = s.themeSystem;
      if (opt.value === 'light') opt.textContent = s.themeLight;
      if (opt.value === 'dark') opt.textContent = s.themeDark;
    }
  }
}

const PROVIDER_DEFAULTS = {
  openai:    { placeholder: 'gpt-4o-mini',                hint: 'e.g. gpt-4o, gpt-4o-mini',             keyHint: 'platform.openai.com' },
  anthropic: { placeholder: 'claude-3-5-haiku-20241022',  hint: 'e.g. claude-opus-4-5, claude-3-5-haiku',keyHint: 'console.anthropic.com' },
  deepseek:  { placeholder: 'deepseek-flash',             hint: 'e.g. deepseek-flash, deepseek-v4-pro', keyHint: 'platform.deepseek.com' },
  custom:    { placeholder: 'model-name',                 hint: 'Model name your API accepts',           keyHint: 'Your custom API key' },
};

// ─── DOM refs ─────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const providerEl      = $('provider');
const apiKeyEl        = $('apiKey');
const apiModelEl      = $('apiModel');
const apiBaseUrlEl    = $('apiBaseUrl');
const responseLangEl  = $('responseLang');
const themeSelectEl   = $('theme-select');
const translateLangEl = $('translate-lang');
const saveBtnEl       = $('saveBtn');
const statusMsgEl     = $('statusMsg');
const toggleKeyEl     = $('toggleKey');
const fieldBaseUrl    = $('baseUrlGroup');
const keyHintEl       = $('keyHint');
const modelHintEl     = $('modelHint');

// ─── Vision API DOM refs ──────────────────────────────────────────────────────
const visionEnabledEl      = $('vision-enabled');
const visionEndpointEl     = $('vision-endpoint');
const visionKeyEl          = $('vision-key');
const visionModelEl        = $('vision-model');
const visionUseTextEl      = $('vision-use-text-config');

// ─── Theme ────────────────────────────────────────────────────────────────────
const _sysDark = window.matchMedia('(prefers-color-scheme: dark)');

function applyTheme(theme) {
  const resolved = (theme === 'system')
    ? (_sysDark.matches ? 'dark' : 'light')
    : theme;
  document.body.dataset.theme = resolved;
}

_sysDark.addEventListener('change', () => {
  if (themeSelectEl && themeSelectEl.value === 'system') {
    applyTheme('system');
  }
});

// ─── Tab switching ────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    $('page-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'history') loadHistory();
  });
});

// ─── AI Settings sub-tab switching ───────────────────────────────────────────
document.querySelectorAll('.ai-tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.ai-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.ai-tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('ai-tab-' + btn.dataset.aiTab)?.classList.add('active');
  });
});

// ─── Settings: Provider UI ────────────────────────────────────────────────────
function updateProviderUI(p) {
  const info = PROVIDER_DEFAULTS[p] || PROVIDER_DEFAULTS.custom;
  refreshModelLanguage();
  modelHintEl.textContent = "";
  keyHintEl.textContent = settingsText(0) + info.keyHint;
  fieldBaseUrl.style.display = p === 'custom' ? '' : 'none';
}

providerEl.addEventListener('change', () => updateProviderUI(providerEl.value));

toggleKeyEl.addEventListener('click', () => {
  const show = apiKeyEl.type === 'password';
  apiKeyEl.type = show ? 'text' : 'password';
  toggleKeyEl.textContent = show ? 'hide' : 'show';
});

// ─── Vision API: key toggle ───────────────────────────────────────────────────
$('vision-key-toggle')?.addEventListener('click', () => {
  const inp = $('vision-key');
  if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
});

// ─── Vision API: "Use Text API config" checkbox ───────────────────────────────
function updateVisionFieldsState() {
  const group = $('vision-fields-group');
  if (!group) return;
  if (visionEnabledEl.checked) {
    group.classList.remove('disabled');
  } else {
    group.classList.add('disabled');
  }
}

visionEnabledEl.addEventListener('change', updateVisionFieldsState);

responseLangEl.addEventListener('change', () => {
  const lang = responseLangEl.value;
  applyUILanguage(lang !== 'auto' ? lang : 'English');
});

visionUseTextEl.addEventListener('change', function() {
  const endpointEl = $('vision-endpoint');
  const keyEl = $('vision-key');
  if (this.checked) {
    endpointEl.value = $('apiBaseUrl')?.value || '';
    keyEl.value = $('apiKey')?.value || '';
    endpointEl.disabled = true;
    keyEl.disabled = true;
  } else {
    endpointEl.disabled = false;
    keyEl.disabled = false;
  }
});

// ─── Settings: Load ───────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('.footer-version').textContent = 'v' + chrome.runtime.getManifest().version;
  chrome.storage.sync.get(
    ['apiProvider','apiKey','apiModel','apiBaseUrl','responseLang','theme','translateLang',
     'visionEnabled','visionApiEndpoint','visionApiKey','visionApiModel','visionUseTextConfig'],
    (data) => {
      const p = data.apiProvider || 'openai';
      providerEl.value = p;
      apiKeyEl.value = data.apiKey || '';
      apiModelEl.value = data.apiModel || '';
      apiBaseUrlEl.value = data.apiBaseUrl || '';
      responseLangEl.value = data.responseLang || 'auto';
      const theme = data.theme || 'system';
      themeSelectEl.value = theme;
      applyTheme(theme);
      applyUILanguage(data.responseLang && data.responseLang !== 'auto' ? data.responseLang : 'English');
      translateLangEl.value = data.translateLang || 'Chinese (Simplified)';
      updateProviderUI(p);

      // Vision settings
      visionEnabledEl.checked   = data.visionEnabled || false;
      visionEndpointEl.value    = data.visionApiEndpoint || '';
      visionKeyEl.value         = data.visionApiKey || '';
      visionModelEl.value       = data.visionApiModel || '';
      visionUseTextEl.checked   = data.visionUseTextConfig || false;
      updateVisionFieldsState();
      if (data.visionUseTextConfig) {
        visionEndpointEl.disabled = true;
        visionKeyEl.disabled = true;
      }
    }
  );
});

// ─── Settings: Save ───────────────────────────────────────────────────────────
let statusTO = null;
function showStatus(msg, type) {
  statusMsgEl.textContent = msg;
  statusMsgEl.className = 'status-msg ' + (type || '');
  if (statusTO) clearTimeout(statusTO);
  if (type === 'success') statusTO = setTimeout(() => {
    statusMsgEl.textContent = '';
    statusMsgEl.className = 'status-msg';
  }, 2200);
}

saveBtnEl.addEventListener('click', () => {
  const provider  = providerEl.value;
  const apiKey    = apiKeyEl.value.trim();
  const apiModel  = apiModelEl.value.trim();
  const apiBaseUrl = apiBaseUrlEl.value.trim();

  if (!apiKey) {
    apiKeyEl.classList.add('warning');
    showStatus('API key is required.', 'warn');
    apiKeyEl.focus();
    return;
  }
  apiKeyEl.classList.remove('warning');

  if (provider === 'custom' && !apiBaseUrl) {
    apiBaseUrlEl.classList.add('warning');
    showStatus('Base URL required for custom providers.', 'warn');
    apiBaseUrlEl.focus();
    return;
  }
  apiBaseUrlEl.classList.remove('warning');

  chrome.storage.sync.set({
    apiProvider: provider,
    apiKey,
    apiModel: apiModel || PROVIDER_DEFAULTS[provider]?.placeholder || 'gpt-4o-mini',
    apiBaseUrl,
    responseLang: responseLangEl.value,
    theme: themeSelectEl.value,
    translateLang: translateLangEl.value,
    // Vision settings — when 'Use Text API config' is checked, persist the
    // resolved text-API values so content.js can read visionApiKey directly.
    visionEnabled:       visionEnabledEl.checked,
    visionApiEndpoint:   visionUseTextEl.checked ? apiBaseUrl : visionEndpointEl.value.trim(),
    visionApiKey:        visionUseTextEl.checked ? apiKey     : visionKeyEl.value.trim(),
    visionApiModel:      visionModelEl.value.trim(),
    visionUseTextConfig: visionUseTextEl.checked,
  }, () => {
    if (chrome.runtime.lastError) showStatus('Error: ' + chrome.runtime.lastError.message, 'warn');
    else {
      applyTheme(themeSelectEl.value);
      const s = UI_STRINGS[responseLangEl.value] || UI_STRINGS['English'];
      showStatus(s.msgSaved, 'success');
    }
  });
});

// ─── History ──────────────────────────────────────────────────────────────────
let allHistory = [];
let filterQuery = '';

function formatTs(ts) {
  const d = new Date(ts);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  return d.toLocaleDateString(undefined, { month:'short', day:'numeric' });
}

function hostnameOf(url) {
  try { return new URL(url).hostname.replace('www.', ''); } catch { return url; }
}

function loadHistory() {
  showHistList();
  chrome.storage.local.get(['ctxHistory'], (data) => {
    allHistory = data.ctxHistory || [];
    renderHistList(allHistory);
  });
}

function renderHistList(items) {
  const list = $('historyList');
  const q = filterQuery.toLowerCase();
  const filtered = q ? items.filter(e => {
    if (e.term.toLowerCase().includes(q)) return true;
    if ((e.explanation || '').toLowerCase().includes(q)) return true;
    if (e.followUps && e.followUps.some(fu =>
      (fu.q || '').toLowerCase().includes(q) || (fu.a || '').toLowerCase().includes(q)
    )) return true;
    return false;
  }) : items;

  if (filtered.length === 0) {
    list.innerHTML = `<div class="hist-empty"><div class="hist-empty-icon">◎</div>${q ? 'No results for "' + filterQuery + '"' : 'No history yet.<br>Select text on any page to get started.'}</div>`;
    return;
  }

  list.innerHTML = filtered.map(entry => {
    const previewText = entry.explanation
      || (entry.followUps && entry.followUps[0] ? `Q: ${entry.followUps[0].q}` : '');
    const preview = previewText.replace(/[#*`>\n]/g, ' ').replace(/\s+/g,' ').trim().slice(0, 100);
    const fuCount = (entry.followUps || []).length;
    const modeBadge = entry.mode === 'translate'
      ? `<span class="hist-followup-badge" title="Translation">⇌</span>`
      : entry.mode === 'ask'
        ? `<span class="hist-followup-badge" title="Ask">?</span>`
        : entry.mode === 'image'
          ? `<span class="hist-followup-badge" title="Image">🖼</span>`
          : '';
    return `<div class="hist-item" data-id="${entry.id}">
      <div class="hist-item-main">
        <div class="hist-term">${escHtml(entry.term)}</div>
        <div class="hist-preview">${escHtml(preview)}</div>
        <div class="hist-meta">
          <span class="hist-time">${formatTs(entry.ts)}</span>
          <span class="hist-site">${escHtml(hostnameOf(entry.url))}</span>
          ${modeBadge}
          ${fuCount > 0 ? `<span class="hist-followup-badge">+${fuCount} Q</span>` : ''}
        </div>
      </div>
      <button class="hist-delete-btn" data-id="${entry.id}" title="Delete">✕</button>
    </div>`;
  }).join('');

  list.querySelectorAll('.hist-item').forEach(el => {
    // Click on main area → detail view
    el.querySelector('.hist-item-main').addEventListener('click', () => {
      const id = el.dataset.id;
      const entry = filtered.find(e => e.id === id);
      if (entry) showDetail(entry);
    });
    // Click on delete btn → remove entry
    el.querySelector('.hist-delete-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      const id = el.dataset.id;
      deleteHistoryEntry(id);
    });
  });
}

async function changeHistory(action, id) {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'CTX_HISTORY', action, id });
    if (!response?.ok) throw new Error('History update failed');
    allHistory = response.history;
    renderHistList(allHistory);
  } catch {
    const notice = document.createElement('div');
    notice.textContent = 'History could not be updated. Please reopen the popup and try again.';
    $('historyList').prepend(notice);
  }
}

function deleteHistoryEntry(id) {
  return changeHistory('delete', id);
}

function showDetail(entry) {
  $('hist-list-view').style.display = 'none';
  const dv = $('hist-detail-view');
  dv.classList.add('active');

  $('detailTerm').textContent = entry.term;
  $('detailDate').textContent = formatTs(entry.ts);

  const body = $('detailBody');
  // explanation is empty for ask-mode entries; followUps holds the Q&A
  let html = '';

  // Show image thumbnail for image-mode entries
  if (entry.mode === 'image' && entry.imageUrl) {
    html += `<div style="margin-bottom:12px;text-align:center">
      <a href="${escHtml(entry.imageUrl)}" target="_blank" rel="noopener" title="Click to view full image">
        <img src="${escHtml(entry.imageUrl)}" style="max-width:100%;max-height:140px;object-fit:contain;border-radius:6px;border:1px solid var(--border);cursor:zoom-in"
             onerror="this.style.display='none'">
      </a>
    </div>`;
  }

  html += entry.explanation
    ? `<div class="detail-explanation">${mdToSimpleHtml(entry.explanation)}</div>`
    : '';

  if (entry.followUps && entry.followUps.length > 0) {
    html += `<div class="detail-qa">`;
    entry.followUps.forEach(fu => {
      html += `<div class="detail-q">${escHtml(fu.q)}</div>
               <div class="detail-a">${mdToSimpleHtml(fu.a || '')}</div>`;
    });
    html += `</div>`;
  }

  html += `<div class="detail-url">From: <a href="${escHtml(entry.url)}" target="_blank">${escHtml(hostnameOf(entry.url))}</a> — ${escHtml(entry.pageTitle || '')}</div>`;
  body.innerHTML = html;
  renderMermaidIn(body);
}

function showHistList() {
  $('hist-list-view').style.display = '';
  const dv = $('hist-detail-view');
  dv.classList.remove('active');
}

$('btnBack').addEventListener('click', showHistList);

// ─── History: search ──────────────────────────────────────────────────────────
$('histSearch').addEventListener('input', (e) => {
  filterQuery = e.target.value;
  renderHistList(allHistory);
});

// ─── History: export ──────────────────────────────────────────────────────────
$('btnExport').addEventListener('click', async () => {
  if (!allHistory.length) return;

  // Group entries by local date (YYYY-MM-DD)
  const byDate = {};
  allHistory.forEach(entry => {
    const date = new Date(entry.ts).toLocaleDateString('sv'); // 'sv' gives YYYY-MM-DD
    if (!byDate[date]) byDate[date] = [];
    byDate[date].push(entry);
  });

  // Build one MD string per date
  function entryToMd(entry) {
    const time = new Date(entry.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const modeLabel = entry.mode === 'translate' ? '⇌ Translate'
      : entry.mode === 'ask' ? '？ Ask'
      : entry.mode === 'image' ? '🖼️ Image'
      : '✦ Explain';
    const site = hostnameOf(entry.url || '');
    let md = `## ${entry.term}\n\n`;
    md += `*${time} · ${modeLabel}${site ? ` · ${site}` : ''}*\n\n`;
    if (entry.mode === 'image' && entry.imageUrl) {
      md += `![${entry.term}](${entry.imageUrl})\n\n`;
    }
    if (entry.explanation) {
      md += `${entry.explanation}\n\n`;
    }
    if (entry.followUps && entry.followUps.length > 0) {
      entry.followUps.forEach(fu => {
        md += `**Q: ${fu.q}**\n\n${fu.a}\n\n`;
      });
    }
    if (entry.url) {
      md += `*Source: [${entry.pageTitle || entry.url}](${entry.url})*\n\n`;
    }
    md += `---\n\n`;
    return md;
  }

  const zip = new JSZip();
  Object.keys(byDate).sort().forEach(date => {
    const entries = byDate[date].slice().sort((a, b) => a.ts - b.ts);
    let content = `# Context Explain — ${date}\n\n`;
    entries.forEach(e => { content += entryToMd(e); });
    zip.file(`${date}.md`, content);
  });

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `context-explain-history-${new Date().toLocaleDateString('sv')}.zip`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
});

// ─── History: clear ───────────────────────────────────────────────────────────
$('btnClear').addEventListener('click', () => {
  if (!confirm('Clear all explanation history? This cannot be undone.')) return;
  changeHistory('clear');
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function mdToSimpleHtml(text) {
  if (!text) return '';

  // Extract LaTeX before marked processes it
  const maths = [];
  const ph = (display, tex) => { maths.push({ display, tex }); return `MATHPH${maths.length-1}MATHPH`; };
  let t = text;
  t = t.replace(/\$\$([\s\S]+?)\$\$/g,  (_, x) => ph(true,  x));
  t = t.replace(/\\\[([\s\S]+?)\\\]/g,   (_, x) => ph(true,  x));
  t = t.replace(/\\\(([^]*?)\\\)/g,       (_, x) => ph(false, x));
  t = t.replace(/(?<![\\$])\$([^$\n]{1,200}?)\$(?!\d)/g, (_, x) => ph(false, x));

  const renderer = new marked.Renderer();
  renderer.code = ({ text: code, lang }) => {
    if (lang === 'mermaid') {
      const escaped = code.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      return `<div class="mermaid-block" data-raw="${escaped}"><div class="mermaid-loading">⟳ Rendering diagram…</div></div>`;
    }
    const escaped = code.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<pre style="background:rgba(0,0,0,0.3);border-radius:5px;padding:8px 10px;font-size:11.5px;overflow-x:auto;margin:6px 0;color:#c8f0a8"><code>${escaped}</code></pre>`;
  };

  let html;
  try { html = marked.parse(t, { gfm: true, breaks: false, renderer }); }
  catch (e) { html = `<p>${t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</p>`; }

  if (typeof katex !== 'undefined') {
    html = html.replace(/MATHPH(\d+)MATHPH/g, (_, i) => {
      const { display, tex } = maths[+i];
      try { return katex.renderToString(tex, { displayMode: display, throwOnError: false }); }
      catch { return `<code>${tex}</code>`; }
    });
  } else {
    html = html.replace(/MATHPH(\d+)MATHPH/g, (_, i) => `<code>${maths[+i].tex}</code>`);
  }
  return html;
}

// ─── API Connection Test ───────────────────────────────────────────────────────
const TEST_TIMEOUT_MS = 10000;

function classifyApiError(e, status) {
  if (e.name === 'AbortError') return 'Request timed out (10s). Check your endpoint URL and network.';
  if (status === 401) return 'Authentication failed (401). Check your API key.';
  if (status === 403) return 'Access forbidden (403). Check API key permissions.';
  if (status === 404) return 'Endpoint not found (404). Check the API base URL.';
  if (status === 429) return 'Rate limited (429). Please try again later.';
  if (status >= 500) return `Server error (${status}). The API provider may have issues.`;
  if (e.message?.includes('Failed to fetch')) return 'Network error. Check your internet connection and endpoint URL.';
  return `Connection failed: ${(e.message || 'Unknown error').substring(0, 200)}`;
}

async function runApiTest(btn, resultEl, endpoint, apiKey, model, isVision) {
  if (btn.dataset.testing === '1') return;
  btn.dataset.testing = '1';
  btn.textContent = '⟳';
  btn.className = 'btn-model-check spinning';
  resultEl.style.display = 'none';
  resultEl.className = 'test-inline-result';

  const resetBtn = (success) => {
    btn.textContent = success ? '✓' : '✗';
    btn.className = 'btn-model-check ' + (success ? 'check-success' : 'check-error');
    btn.dataset.testing = '';
    setTimeout(() => {
      btn.textContent = '✓';
      btn.className = 'btn-model-check';
    }, 4000);
  };

  const showResult = (success, message) => {
    resultEl.style.display = 'block';
    resultEl.className = 'test-inline-result ' + (success ? 'success' : 'error');
    resultEl.textContent = (success ? '✓ ' : '✗ ') + (success || currentModelLanguage === 'English' ? message : settingsText(2) + '：' + settingsText(3));
    resetBtn(success);
  };

  if (!endpoint) { showResult(false, 'Endpoint is not configured.'); return; }
  if (!apiKey)   { showResult(false, 'API key is not configured.');  return; }
  if (!model)    { showResult(false, 'Model is not configured.');     return; }

  let url;
  try { url = new URL(endpoint.replace(/\/$/, '') + '/chat/completions'); }
  catch { showResult(false, 'Invalid endpoint URL format.'); return; }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), TEST_TIMEOUT_MS);
  const startTime = Date.now();
  let httpStatus = null;

  try {
    // 66×66 Chrome logo PNG (assets/Vision API Test.png) — valid for all vision providers
    const TEST_IMAGE_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABCCAIAAABsNpe/AAAACXBIWXMAAAsTAAALEwEAmpwYAAAL1ElEQVRoge2ae4xc1X3Hv99z7rxnX7PrXcde7xrWDrYBY6B+BCd1eYVXIESNUkVIqInkiFZJ6ogqqKKN2lRqaQgqgQQRuSGJlUJonuVZSImxE9uA7bpgsPELe83aXnvXM96dnee99/z6x7l3Zo3d9S67Thzkn0ajO/f5+5zf4/zO7w5FBH/4on7fCkyNnMc4l+Q8xrkk5zHOJfmAYDhn46ZSKpr+I+boEfdYvxQKxq0QYDSqmjMq2eDMnKlmdjKenMInTimGMe6enYXnnym9ttGUS6ZcRqkknksREVFaMxZXjsNUWicTiaXLk9ffxJ6LqPXkn8wpKEZEzNCJ6v9uyT32aHnXLgIgAVABAEmSwcNIiJCE3VBMLFyU/PQd0UuvYEsLwtN+HxjFYuGFZ0ZeeqG0bYt4fqDrKIY6QLgxeosgtIpdsih9+59GPrKCiffpaZPC8Pbtzn77geLWLaZcJiiQYOxFoMlTMIJvay4RKgURay/dkI4vvir9+btUZ/fvEMMY9+03B/7l66UdOwDQ6qZY9xytQm1FqXo+ZOhnIZVYF7R7YhfNb/zK36i58yYaMO8HQ6rV4vNPDTzyr342d9IYgyEQT+tU9XNOMQ4BKFKgWzMNd34hduNtiEbHr9KE5w3xvZGnfjbwrfv9weMwBoAdCAnVDCLVoHbodHcR+02F+hlGAPjHs/nHHqm+9Ly9+dnCcN/eMfjdh/2hIQCoeYsEvnTaS0jWUUPY4DojtFQKUBAKAD8/nP+3R/w9O88Whte7f+C+v/ePHw9+GwOAEMCIDdaTbsxTM1XAQtotglaF0G72p/KHsvkH7zN9vVOPYYqF7KMPl956C4BQqAilSKmpDKl7iATuVjdCXWwOCJnEAKoWLcGjYOju2V149FtSKo5Ht/HO4iIytPHl/Mbf1DUWgWIwm9nhYHAmSWqqWEw1NulUijpCJSIVeiX4efEq9gYElDWLgiJheYRQgDFQyjuy2f+fl5zlnzjZEyeBMVwZfvzo+sVOOYPQHepxAQAUAEJSAKepKbHi6sQli5yL5jszZ6lUGhC4A6gckZHdktuEE/8tlYMARDzSAaoARGquUYUoIApUmfg5qh9FtGVs9cabcNcf3HTvpgdveeXIp9cdrSdPBYKCer1BMrniT1q+8CU9c5Y6/ZQs4o+gsBv77zPZF0kt4ocwEPEAQDwgChqgCrbqi3/E9uumAMM3/hd//XebB3bFXP+BNe9My1WDA0qFIQ5SMeI03HRrZtU9TDcUKug97j/3RmnDPrcv5yviwlbnytnOrZclOjMqFSO8Ydn7ddP/OKRQAyCdgGSUqNR1askvgvJmMhi7snvveOEeu331gfKdz/YmS55NKbVQAdF026ea/nKVk2nbd8xfva747PZKrvje3N/RwOsXxFeuSPa0a1SPmnful/7HIH543AG8U0n04s1sWDCGhuPKVL/av15ERMQ3Zst0560LGhBOcAEDTHLJssyqe5xM24a97p2rc0+8VjqVAcDRvDzxWunO1bkNe6uIdqg5X2PbbYBDGlIDHqlJhzTWOAAgnhx5amwNz4xRcssbj2wDYEQUORzT6xc0DKcjrOd7o9vaM3d9memGfcf8rz451Jsz/v9vY1/QmzNffXJ43zEfTqOafQ+i7SJKhIAjgWWiAQNApSS7TvyxMu+ZMQ6P9Be8khGxJGJk24zktp6U1MaaKrVkqXPhnEIFq9cV+06Mq4joO2FWrysWKiKJLtX2SVCDArqnnimiYPIs908OI9+fd8sUUIKyp6L5k8VtQ6lwtBKJxOKPqESyL+v9akd5DDuMFl/w7PZK73GfOsXGy6GaCACOzdyktt+kQzowIygfmhRGwSu6xpNR84+I9KedJz/W7iuQ1A2NTs9ckE+/Xj6an0C9nCuaZ7eXAUh6HiIdoC3OHQACz+bm4In+sFSOTgojWx4qeS5MUFkYY2y4b+tK7O5MiohKJpwZMwFsPfDeDHNG2bi3CoCJ2dDN4fDrgCdwAAcApQy/NCkM13N9E45KmJ2NyEBMr13QVIxrOlHd2AzgneMTxjiUMwDgNFLFDGA/pAYcwgEc0AUFUoBfnhSGrfesBUz40YBPrJ2dODA9Xqt3zMTXkTq8NqwVQfGtL0nIg6DUGStznBkjpiO1MluRFAHgAyLiaj6xuLkI3xRGAHS2THj1MrtNA4Cbg5StRwljQg1AqMPYcIQxUbFJYSQjySh1mG3D5Z4R67rb22L/MT/iHToIYHnPBJadVq7sjgBA+V2aEbuHJ2eqYKdqVtHMpDCmJduSOmoBAt8NnceGyoZ2f8/RfQBuXhhvSU7AIB0NvPWyOCBS3Cv+gAgFWsQntQFIMfWgT4iTnhTGh9LtKR0PFhICEZgwVKzT9mnvGW9vuVrqbtW3XBrTZ1gaBKKJ6xfEOzNa/ILkNok/BAoBMjBpGC3aANDNjHdOCmN6qj2pY6G1YctJ62NGxIf4kKcPvXJwpD8V48oVyc7mcRmks1mtXJFMxcjCHnPiZUADun73MLgNfADQDZKYHEYiEl86c5EvEhpEKDCj6mIRyZXzD21dk68Uetr1Nz7T2N2ixrCJJrpb1Df+rLGnXRereb/3AbrHSA2KUESM7Q6Rioxap1KtV1OP1VAc18jdPOdahl5kLVA7ZKkArD3wyjc3fnewmF0+N7pmZctnlyQ6Gk6D0pJUn12SWLOyZfmc6GAx++obD2LoN0HP184VVAKQSuALfLGZt/2WsTUc13rDiNzxn19+M7vfblsL2AEYdTkd8vaea/76qrsaYqlCRfqy/tOvl7f2uu8Mer5gVote3hO9eWG8u1WnYsxXCv+++aEb3Me7ogURw7D/QIqITzgI6hHDxuv1ZT8IS5VJYABYu/+3d798f8V4YWQHK3Ajolif+ETkqpmLVi3+856W7mQ0ztO1AopuqW/o8EOv/eDi4oufmz4YCdQVBL03Y/tahCcAEVXzvsdp146t3nhbCpdPv2Rpx/x1h98YFeJQDDYoQdlOkd/2bduT7f3ohy5d2vVHC6bNbU+0NsUbAIxUiweHD+8c2PP64bf+68CGGTxx9wVDDiDUEEOlRQwpQND+ETiAx8YVbLr8jOqN1xoi8su3n/vnV1cX3Io1wuhDtW1bp9ijKSeeiaUTOhZREQCucQtuabCcL3kVEbmvO3d7Jm+TLGAkaKrAOlhwO5VRc/6J7TdOWYOH5A1zrll74JWX+rbUGEZXioGVWCccrpaGq/WydLTFrki7n2odBhVBESNBOleAIZU9kRDVeiNb//iMDBPrGiYjib9a+vmFmR4JpTZ72FRZ8zd7VBFhKguOKoAi0x3/H2YN2U5HkIioLIOd9UhFCNPL0PUX0Knx6DaxYq4nc8HffuxLHYmmGkA4adVFRIwEQS+hBWrkGrglU+1KeIAClFU67Jqq4OUAFCNdqudrTHSNU7EJ16Tzp839yuLPZSJJW4l4Ip5IWJ7AN1IHsE3n0G5WOiP+zW2lhAr2qMBko9Sgg0iH6lqF9LzxazXhN7GK6qYPX+P5lYc3/6i/PKRGNcNrEVKLAbw3iviJtsqlSdtZO2kE6x336AzOuhvTbhh7oniPvM+XZr7xdw7s+cd1D24b3GcEtakj6EOHFgjjB9buFyW9H188lKYB/NF3EzH27QhTV6oL70V63tg9winDsNJ74t3vvPr9lw9uzVaLdl5XAv/kFwEiAhCQOOWH8/NXpKsIurS21VhTJI2m5ez+IpM970OTyb5QLlSL6/dv+vGbT23u31k9ZcleM4VDc3vGv/eCfKMO16Ii9t0tVAwNy9h6Hds+jjHrv7OIYZXOlnLbDm1f8/pPNx7ZYYffhBnWQCjocOT+DxeWNbvKwL6GCUqy1EI1YyUbL0OkaTzzw1nEqIlv/F2D+57b+eK63q0Ft5CvllzjF72KJ+aTrd4355XBKFUKTFIn0biM025Aau6U/P1mKjFqUnTLfScOvTt0aKRazBVzFa96bRt6UnHoJKLtiHYw3gGVmMInnhWM3718QP5PdR7jXJLzGOeSnMc4l+Q8xrkkHxCM/wOfZUZp93oE8QAAAABJRU5ErkJggg==';

    const messages = isVision ? [{
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: TEST_IMAGE_B64 } },
        { type: 'text', text: 'Describe this image in 3 words.' }
      ]
    }] : [{
      role: 'user',
      content: 'Reply with exactly: OK'
    }];

    const resp = await fetch(url.href, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
      body: JSON.stringify({ model, messages, max_tokens: 32, stream: false }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    httpStatus = resp.status;
    const latency = Date.now() - startTime;

    if (!resp.ok) {
      const body = await resp.text().catch(() => '');
      console.error('[Context Explain] API test error:', resp.status, body);
      let detail = '';
      try {
        const parsed = JSON.parse(body);
        detail = parsed?.error?.message || '';
        // Some providers (e.g. OpenRouter) include more detail in metadata
        const meta = parsed?.error?.metadata;
        if (meta) {
          const extra = meta.raw || meta.details || JSON.stringify(meta);
          if (extra && extra !== '{}') detail += (detail ? ' — ' : '') + extra;
        }
      } catch {}
      throw Object.assign(new Error(detail || `HTTP ${resp.status}`), { status: resp.status });
    }

    const json = await resp.json().catch(() => null);
    console.log('[Context Explain] API test success:', json);
    if (!json?.choices?.[0]) throw new Error('Unexpected response structure from API.');

    const timestamp = new Date().toLocaleTimeString();
    showResult(true, `${settingsText(1)} — ${latency} ms (${timestamp})`);

  } catch (e) {
    clearTimeout(timeoutId);
    console.error('[Context Explain] API test exception:', e);
    showResult(false, classifyApiError(e, e.status || httpStatus));
  }
}

// Wire up test buttons after DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  $('test-text-api')?.addEventListener('click', () => {
    const provider = providerEl.value;
    let endpoint = apiBaseUrlEl.value.trim();
    if (!endpoint) {
      const defaults = { openai: 'https://api.openai.com/v1', anthropic: 'https://api.anthropic.com/v1', deepseek: 'https://api.deepseek.com/v1' };
      endpoint = defaults[provider] || '';
    }
    runApiTest(
      $('test-text-api'),
      $('test-text-result'),
      endpoint,
      apiKeyEl.value.trim(),
      (apiModelEl.value || PROVIDER_DEFAULTS[provider]?.placeholder || '').trim(),
      false
    );
  });

  $('test-vision-api')?.addEventListener('click', () => {
    const endpoint = visionUseTextEl.checked
      ? (apiBaseUrlEl.value.trim() || (() => {
          const defaults = { openai: 'https://api.openai.com/v1', anthropic: 'https://api.anthropic.com/v1', deepseek: 'https://api.deepseek.com/v1' };
          return defaults[providerEl.value] || '';
        })())
      : visionEndpointEl.value.trim();
    const apiKey = visionUseTextEl.checked ? apiKeyEl.value.trim() : visionKeyEl.value.trim();
    runApiTest(
      $('test-vision-api'),
      $('test-vision-result'),
      endpoint,
      apiKey,
      visionModelEl.value.trim(),
      true
    );
  });
});

// Fetch model IDs without replacing the editable model field.
const MODEL_ENDPOINTS = {openai: 'https://api.openai.com/v1', anthropic: 'https://api.anthropic.com/v1', deepseek: 'https://api.deepseek.com/v1'};
async function fetchModelList(vision) {
  const btn = $(vision ? 'fetch-vision-models' : 'fetch-text-models');
  const status = $(vision ? 'vision-models-result' : 'text-models-result');
  const list = $(vision ? 'vision-model-list' : 'text-model-list');
  const useText = !vision || visionUseTextEl.checked;
  const provider = useText ? providerEl.value : 'custom';
  const endpoint = (useText ? (provider === 'custom' ? apiBaseUrlEl.value : MODEL_ENDPOINTS[provider]) : visionEndpointEl.value).trim().replace(/\/+$/, '');
  const key = (useText ? apiKeyEl.value : visionKeyEl.value).trim();
  list.replaceChildren();
  status.dataset.state = '';
  if (!endpoint || !key) { status.textContent = modelCopy()[2]; return; }
  btn.disabled = true;
  status.textContent = modelCopy()[1];
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const headers = provider === 'anthropic'
      ? {'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'}
      : {'Authorization': 'Bearer ' + key};
    const models = [];
    let next = '';
    do {
      const url = new URL(endpoint + '/models');
      if (next) url.searchParams.set('after_id', next);
      const response = await fetch(url.href, {headers, signal: controller.signal});
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      if (!Array.isArray(data.data)) throw new Error('Invalid model list response');
      for (const item of data.data) if (typeof item.id === 'string') models.push(item.id);
      next = provider === 'anthropic' && data.has_more ? data.last_id : '';
    } while (next && models.length < 5000);
    [...new Set(models)].sort().forEach(id => { const option = document.createElement('option'); option.value = id; list.appendChild(option); });
    if (!list.children.length) throw new Error('No models returned');
    status.dataset.state = 'success';
    status.textContent = modelCopy()[3];
  } catch (e) {
    status.textContent = modelCopy()[4] + ' (' + (e.name === 'AbortError' ? 'timeout' : e.message) + ')';
  } finally { clearTimeout(timer); btn.disabled = false; }
}
function setupModelSearch(prefix, input) {
 const list = $(prefix+'-model-list'), results = $(prefix+'-model-results');
 let active = -1;
 const close = () => { results.hidden=true; input.setAttribute('aria-expanded','false'); input.removeAttribute('aria-activedescendant'); };
 const render = () => {
   const models = Array.from(list.children, option=>option.value);
   if (!models.length) { close(); return; }
   const query=input.value.trim();
   const matches=models.filter(id=>id.toLowerCase().includes(query.toLowerCase())).slice(0,100);
   results.replaceChildren(); active=-1;
   const values=matches.length ? matches : [query];
   for (const [i,value] of values.entries()) {
     const item=document.createElement('button'); item.type='button'; item.id=prefix+'-model-option-'+i; item.setAttribute('role','option');
     item.textContent=matches.length ? value : modelCopy()[5]+value;
     item.addEventListener('mousedown',e=>e.preventDefault());
     item.addEventListener('click',()=>{input.value=value; close(); input.focus();});
     results.appendChild(item);
   }
   results.hidden=false; input.setAttribute('aria-expanded','true');
 };
 input.addEventListener('input',render); input.addEventListener('focus',render);
 input.addEventListener('blur',close);
 input.addEventListener('keydown',e=>{
   if(e.key==='Escape') {close();return;}
   if(e.key==='ArrowDown'||e.key==='ArrowUp') {
     e.preventDefault(); if(results.hidden) render();
     const items=Array.from(results.children); if(!items.length)return;
     active=(active+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;
     items.forEach((item,i)=>item.setAttribute('aria-selected',String(i===active)));
     input.setAttribute('aria-activedescendant',items[active].id); items[active].scrollIntoView({block:'nearest'});
   } else if(e.key==='Enter' && !results.hidden && active>=0) {e.preventDefault();results.children[active].click();}
 });
}
setupModelSearch('text', apiModelEl);
setupModelSearch('vision', visionModelEl);

$('fetch-text-models').addEventListener('click', () => fetchModelList(false));
$('fetch-vision-models').addEventListener('click', () => fetchModelList(true));
[providerEl, apiBaseUrlEl, apiKeyEl].forEach(el => el.addEventListener('change', () => $('text-model-list').replaceChildren()));
[visionEndpointEl, visionKeyEl, visionUseTextEl].forEach(el => el.addEventListener('change', () => $('vision-model-list').replaceChildren()));

// ─── Mermaid via sandboxed iframe (bypasses popup CSP) ───────────────────────
let _sandboxIframe = null;
let _sandboxReady = false;
let _sandboxQueue = []; // [{id, code, resolve}]
let _pendingRenders = {}; // id → {el, resolve}

function getSandbox() {
  if (_sandboxIframe) return _sandboxIframe;
  const iframe = document.createElement('iframe');
  iframe.src = chrome.runtime.getURL('mermaid-sandbox.html');
  iframe.style.cssText = 'position:absolute;width:0;height:0;border:0;visibility:hidden';
  document.body.appendChild(iframe);
  _sandboxIframe = iframe;

  window.addEventListener('message', (e) => {
    const { id, svg, error } = e.data || {};
    if (!id || !_pendingRenders[id]) return;
    const { el } = _pendingRenders[id];
    delete _pendingRenders[id];
    if (svg) {
      el.innerHTML = svg;
      el.removeAttribute('data-raw');
    } else {
      el.innerHTML = `<pre style="color:#d06060;font-size:11px">Mermaid: ${error||'render failed'}</pre>`;
    }
  });

  iframe.addEventListener('load', () => {
    _sandboxReady = true;
    _sandboxQueue.forEach(({ id, code, el }) => {
      _pendingRenders[id] = { el };
      iframe.contentWindow.postMessage({ id, code }, '*');
    });
    _sandboxQueue = [];
  });

  return iframe;
}

function renderMermaidIn(container) {
  const blocks = container.querySelectorAll('.mermaid-block[data-raw]');
  if (!blocks.length) return;

  const iframe = getSandbox();
  blocks.forEach((el, i) => {
    const code = el.dataset.raw.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
    const id = `mp${Date.now()}${i}`;
    if (_sandboxReady) {
      _pendingRenders[id] = { el };
      iframe.contentWindow.postMessage({ id, code }, '*');
    } else {
      _sandboxQueue.push({ id, code, el });
    }
  });
}

const PROMPT_UI = {"English": ["Prompts", "Save prompts", "Restore defaults", "Saved. Applies to new queries.", "Edit prompts for the current interface language. Variables: {{selectedText}}, {{contextBefore}}, {{contextAfter}}, {{question}}, {{targetLang}}, {{responseLang}}. Save before switching language.", "Explain", "Ask", "Translate", "Recap", "Text system instructions", "Translation system instructions", "Image explanation", "Image system instructions"], "Chinese (Simplified)": ["提示词管理", "保存提示词", "恢复默认", "已保存，新查询将使用这些提示词。", "按当前界面语言编辑提示词。可用变量：{{selectedText}}（所选文本）、{{contextBefore}}（前文）、{{contextAfter}}（后文）、{{question}}（问题）、{{targetLang}}（翻译目标语言）、{{responseLang}}（回复语言）。切换语言前请先保存。", "文本解释", "文本提问", "上下文翻译", "对话总结", "文本系统指令", "翻译系统指令", "图片解释", "图片系统指令"], "Japanese": ["プロンプト", "保存", "既定値に戻す", "保存しました。新しい質問に適用されます。", "現在の表示言語のプロンプトを編集します。変数：{{selectedText}}, {{contextBefore}}, {{contextAfter}}, {{question}}, {{targetLang}}, {{responseLang}}。言語変更前に保存してください。", "説明", "質問", "翻訳", "要約", "テキストのシステム指示", "翻訳のシステム指示", "画像の説明", "画像のシステム指示"], "Korean": ["프롬프트 관리", "저장", "기본값 복원", "저장되었습니다. 새 질문에 적용됩니다.", "현재 표시 언어의 프롬프트를 편집합니다. 변수: {{selectedText}}, {{contextBefore}}, {{contextAfter}}, {{question}}, {{targetLang}}, {{responseLang}}. 언어 변경 전에 저장하세요.", "텍스트 설명", "질문", "번역", "요약", "텍스트 시스템 지침", "번역 시스템 지침", "이미지 설명", "이미지 시스템 지침"]};
function renderPromptEditors() {
 const lang=ctxPromptLanguage(currentModelLanguage), t=PROMPT_UI[lang];
 $('prompts-tab').textContent=t[0];$('save-prompts').textContent=t[1];$('reset-prompts').textContent=t[2];$('prompt-help').textContent=t[4];$('prompt-status').textContent='';
 const container=$('prompt-editors');container.replaceChildren();
 Object.keys(CTX_PROMPT_DEFAULTS.English).forEach((key,index)=>{
   const label=document.createElement('label');label.textContent=t[index+5];label.htmlFor='prompt-'+key;
   const input=document.createElement('textarea');input.id='prompt-'+key;input.className='prompt-editor';input.dataset.promptKey=key;input.value=ctxPromptTemplate(key,lang);
   container.append(label,input);
 });
}
$('save-prompts').addEventListener('click',async()=>{
 const lang=ctxPromptLanguage(currentModelLanguage);
 const stored=await chrome.storage.local.get('ctxPromptOverrides');const overrides=stored.ctxPromptOverrides || {};
 overrides[lang]={};document.querySelectorAll('[data-prompt-key]').forEach(el=>{if(el.value.trim())overrides[lang][el.dataset.promptKey]=el.value;});
 await chrome.storage.local.set({ctxPromptOverrides:overrides});ctxPromptOverrides=overrides;
 $('prompt-status').textContent=PROMPT_UI[lang][3];
});
$('reset-prompts').addEventListener('click',async()=>{
 const stored=await chrome.storage.local.get('ctxPromptOverrides');const overrides=stored.ctxPromptOverrides || {};delete overrides[ctxPromptLanguage(currentModelLanguage)];
 await chrome.storage.local.set({ctxPromptOverrides:overrides});ctxPromptOverrides=overrides;renderPromptEditors();
});
ctxPromptsReady.then(renderPromptEditors);
